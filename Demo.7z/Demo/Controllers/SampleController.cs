﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Amazon.S3.Util;
using Demo.Services;

namespace Demo.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class SampleController : ControllerBase
    {
        private readonly IS3Service _service;
        public SampleController(IS3Service service)
        {
            _service = service;
        }


        [HttpGet]
        public ActionResult<string> GetMessage()
        {
            try
            {
                return "Hello World !";
            }
            catch (Exception ex)
            {
                return "Error in GetMessage method !";
            }
        }


        [HttpPost]
        public async Task<ActionResult> WriteLog(Loggs oLoggs)
        {
            string mssg = await _service.WriteContentObjectInAmazons3(oLoggs.logMessage);
            return Ok(mssg); 

        }

        [HttpGet]
        public async Task<ActionResult> ReadLog()
        {
           string mssg= await _service.GetObjectFromAmazons3();
           return Ok(mssg);
        }




    }
}
       